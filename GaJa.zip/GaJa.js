const canvas = document.querySelector("canvas");
const c = canvas.getContext("2d");

let GravitySpeed = 10

setInterval(Game, 10);
function Loop() {
}

function checkKeyPress(key) {
  Press()
}

function ReleaseKey(Key) {
  Release()
}



// Adding the listeners for the player movement
window.addEventListener("keydown", checkKeyPress, false);
window.addEventListener("keyup", ReleaseKey, false)

function SpriteSheet() {
  
}

function Distance(Object, Object2) {
  var x = Math.pow(Object.x + Object2.x, 2)
  var y = Math.pow(Object.y + Object2.y, 2)
  var Distance = Math.sqrt(x + y)
  return Distance
}

function Collision(Thing, Thing2, offset) {
  var D = Distance(Thing.x, Thing2.x, Thing.y, Thing2.y)
  if (D === 0) {
    let C = true
  }
  else {
    let C = false
  }
  return C
}

function Gravity(Player, Enemy) {
  if (Collision(Player, Enemy) === true) {
    GravitySpeed = 10
    SetTimeout(100, Gravity)
  } else {
    Player.y += GravitySpeed
    GravitySpeed += 10
    SetTimeout(100, Gravity)
  }
}