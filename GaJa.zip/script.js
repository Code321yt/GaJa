PlayerX = 10
PlayerY = 50

function Game() {
  c.clearRect(0, 0, canvas.width, canvas.height);
  Player()
}

function Player() {
  PlayerX = 10
  PlayerY = 50
  c.fillRect(PlayerX, PlayerY, 150, 75);
}

function Press() {
  switch (key.keyCode) {
    case 39: // RIGHT ARROW
      PlayerX += 20
      break;
    case 37: // LEFT ARROW
      PlayerX -= 20
      break;
  }
}


